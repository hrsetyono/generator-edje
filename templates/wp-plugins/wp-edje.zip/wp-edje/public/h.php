<?php
/*
  Main portal for calling all static methods
*/
class H {
  function __construct() {

  }

  ///// POST TYPE

  static function register_post_type($name, $args = array() ) {
    $pt = new H_PostType($name, $args);
    $pt->init();
  }

  static function register_taxonomy($name, $args) {
    $tx = new H_Taxonomy($name, $args);
    $tx->init();
  }

  static function register_columns($name, $args) {
    if(!is_admin() ) { return false; }

    $pc = new H_PostColumn($name, $args);
    $pc->init();
  }

  ///// ACTIONS - TODO: still not working

  static function add_actions( $post_type, $actions ) {
    if(!is_admin() ) { return false; }

    $pa = new H_PostAction( $post_type, $actions );
    $pa->add();
  }

  static function replace_actions( $post_type, $actions ) {
    if(!is_admin() ) { return false; }

    $pa = new H_PostAction($post_type, $actions);
    $pa->replace();
  }

  ///// ADMIN MENU

  static function remove_menu( $args ) {
    if(!is_admin() ) { return false; }

    $menu = new H_SidePanel( $args );
    $menu->remove();
  }

  static function add_menus( $args ) {
    if(!is_admin() ) { return false; }

    $menu = new H_SidePanel( $args );
    $menu->add();
  }

  static function add_menu($title, $args) {
    if(!is_admin() ) { return false; }

    $new_args = array(
      $title => $args
    );
    H::add_menus( $new_args );
  }

  static function add_submenu( $parent_title, $args ) {
    if(!is_admin() ) { return false; }

    $new_args = array(
      $parent_title => array(
        'position' => "on $parent_title",
        'submenu' => $args
      )
    );
    H::add_menus( $new_args );
  }

  static function add_menu_counter($parent_title, $count_function) {
    if(!is_admin() ) { return false; }

    $new_args = array(
      $parent_title => array(
        'position' => "on $parent_title",
        'counter' => $count_function,
      )
    );

    H::add_menus( $new_args );
  }


  ///// CUSTOMIZER

  /*


    @param obj $wp_customize - WP_Customize object from customize_register action.
  */
  static function customizer( $wp_customize ) {
    return new H_Customizer( $wp_customize );
  }
}
