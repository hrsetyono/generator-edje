## 0.5.0

- *Manage Stock* is not ticked by default.
- Putting 0 on Quick Stock field sets the status into *Out of Stock*.
- Putting any number other than 0 on Quick Stock field will tick *Manage Stock*.

## 0.4.1

- Re-enable the variation manual sorting by drag-n-drop.
- Fixed bug where additional variation isn't set the global price initially.

## 0.4.0

- Changing Main Backorder will change all variations too
- Fixed a bug where global price are missing
- Hide the attribute checkboxes

## 0.3.1

- Automatically tick "Used for Variations" when adding new attribute
- Remove the code that hide some fields in Variation detail

## 0.3.0 - First Release

- Revamped interface for Variations
- Hide most fields from Variation detail
