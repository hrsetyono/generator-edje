<?php
require_once 'hoo-functions.php';
require_once 'hoo-checkout.php';
require_once 'hoo-general.php';
require_once 'hoo-thankyou.php';
